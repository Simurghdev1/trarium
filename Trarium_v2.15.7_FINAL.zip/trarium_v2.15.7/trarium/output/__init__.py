"""ذخیره نتیجه ترجمه در فایل."""

import re
from pathlib import Path
from datetime import datetime
from xml.sax.saxutils import escape as xml_escape
from rich.console import Console

console = Console()

_FONT_DIR = Path(__file__).parent.parent / "fonts"
_FONT_PATH = _FONT_DIR / "Sahel.ttf"


def save_as_text(result, output_path: str = None) -> str:
    if output_path is None:
        safe = "".join(c for c in result.title if c.isalnum() or c in " _-").strip()
        output_path = f"{safe}_translated.txt"
    path = Path(output_path)
    path.write_text(f"{result.translated_text}\n\n---\nترجمه شده با Trarium\n", encoding="utf-8")
    console.print(f"  💾 ذخیره شد: [bold green]{path}[/] ({path.stat().st_size:,} بایت)")
    return str(path)


def save_as_pdf(result, output_path: str = None) -> str:
    """ترجمه رو به PDF ذخیره می‌کنه — PyMuPDF insert_htmlbox با RTL."""
    import pymupdf

    if output_path is None:
        safe = "".join(c for c in result.title if c.isalnum() or c in " _-").strip()
        output_path = f"{safe}_translated.pdf"

    path = Path(output_path)
    doc = pymupdf.open()

    text = result.translated_text
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]

    # ساخت صفحات PDF
    page_width = 595   # A4
    page_height = 842
    margin = 50
    usable_width = page_width - 2 * margin
    font_size = 12

    page = doc.new_page(width=page_width, height=page_height)
    y = margin

    for para in paragraphs:
        # محاسبه تقرعی ارتفاع متن
        chars_per_line = max(int(usable_width / (font_size * 0.5)), 10)
        est_lines = max(1, (len(para) + chars_per_line - 1) // chars_per_line)
        est_height = est_lines * font_size * 2.2

        # اگه جا نمیشه، صفحه جدید
        if y + est_height > page_height - margin:
            page = doc.new_page(width=page_width, height=page_height)
            y = margin

        rect = pymupdf.Rect(margin, y, page_width - margin, y + est_height + font_size * 2)

        # استفاده از insert_htmlbox با RTL
        html_text = f"""<div dir="rtl" style="
            font-family: 'Sahel', Tahoma, sans-serif;
            font-size: {font_size}pt;
            line-height: 2.0;
            text-align: right;
            color: #222;
        ">{xml_escape(para)}</div>"""

        try:
            rc = page.insert_htmlbox(rect, html_text)
            if rc >= 0:
                y += est_height + font_size
            else:
                # overflow — کوچکتر بنویس
                rect2 = pymupdf.Rect(margin, y, page_width - margin, page_height - margin)
                page.insert_htmlbox(rect2, html_text)
                y = page_height - margin
        except Exception:
            # fallback: insert_text خط به خط
            try:
                page.insert_font(fontname="Sahel", fontfile=str(_FONT_PATH))
                for line in para.split("\n"):
                    if y + font_size * 2 > page_height - margin:
                        page = doc.new_page(width=page_width, height=page_height)
                        y = margin
                        page.insert_font(fontname="Sahel", fontfile=str(_FONT_PATH))
                    r = pymupdf.Rect(margin, y, page_width - margin, y + font_size * 2)
                    page.insert_textbox(
                        r, line,
                        fontname="Sahel", fontfile=str(_FONT_PATH),
                        fontsize=font_size, color=(0.13, 0.13, 0.13),
                        align=pymupdf.TEXT_ALIGN_RIGHT,
                    )
                    y += font_size * 2
            except Exception as fallback_error:
                raise RuntimeError(f"نوشتن متن در PDF شکست خورد: {fallback_error}") from fallback_error

    doc.save(str(path))
    doc.close()
    console.print(f"  💾 ذخیره شد: [bold green]{path}[/] ({path.stat().st_size:,} بایت)")
    return str(path)


def save_as_epub(result, output_path: str = None) -> str:
    """ترجمه رو به EPUB ذخیره می‌کنه."""
    import zipfile, re, uuid

    if output_path is None:
        safe = "".join(c for c in result.title if c.isalnum() or c in " _-").strip()
        output_path = f"{safe}_translated.epub"

    path = Path(output_path)
    book_id = str(uuid.uuid4())
    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")  # B14 fix
    title_safe = xml_escape(result.title)  # B20 fix: escape XML special chars

    css = b"@font-face{font-family:Sahel;src:url(../fonts/Sahel.ttf)} body{font-family:Sahel,Tahoma,Arial,sans-serif;line-height:1.8;margin:2em;color:#333;direction:rtl;text-align:right}\nh1{text-align:center;color:#2c3e50}\nh2{color:#34495e}\np{margin:.5em 0;text-align:right}"

    sections = [s.strip() for s in re.split(r'\n---\s+', result.translated_text) if s.strip()]
    chapter_files, nav_points, manifest_items, spine_refs = [], "", "", ""

    for i, section in enumerate(sections):
        lines = section.split("\n", 1)
        ch_title = xml_escape(lines[0].strip().replace("---", "").strip() or f"بخش {i+1}")
        content = lines[1].strip() if len(lines) > 1 else ""
        paras = "".join(f"<p>{xml_escape(p.strip())}</p>\n" for p in content.split("\n") if p.strip())
        fname = f"ch{i+1}.xhtml"
        chapter_files.append(fname)
        nav_points += f'<navPoint id="np{i+1}" playOrder="{i+1}"><navLabel><text>{ch_title}</text></navLabel><content src="{fname}"/></navPoint>\n'
        manifest_items += f'<item id="ch{i+1}" href="{fname}" media-type="application/xhtml+xml"/>\n'
        spine_refs += f'<itemref idref="ch{i+1}"/>\n'

    titles_list = [s.split("\n", 1)[0].strip().replace("---", "").strip() or f"بخش {j+1}" for j, s in enumerate(sections)]
    nav_li = "".join(f'<li><a href="{chapter_files[i]}">{xml_escape(titles_list[i])}</a></li>\n' for i in range(len(titles_list)))

    with zipfile.ZipFile(str(path), "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        zf.writestr("META-INF/container.xml", '<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>')
        zf.writestr("OEBPS/content.opf", f'<?xml version="1.0"?><package xmlns="http://www.idpf.org/2007/opf" unique-identifier="BookId" version="3.0"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="BookId">urn:uuid:{book_id}</dc:identifier><dc:title>{title_safe}</dc:title><dc:language>{result.target_lang}</dc:language><dc:creator>Trarium</dc:creator><meta property="dcterms:modified">{now}</meta></metadata><manifest><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/><item id="css" href="style.css" media-type="text/css"/><item id="tp" href="title.xhtml" media-type="application/xhtml+xml"/>{manifest_items}<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/></manifest><spine toc="ncx"><itemref idref="tp"/>{spine_refs}</spine></package>')
        zf.writestr("OEBPS/toc.ncx", f'<?xml version="1.0"?><ncx xmlns="http://www.daisy.org/z3986/2005/ncx/"><head><meta name="dtb:uid" content="urn:uuid:{book_id}"/></head><docTitle><text>{title_safe}</text></docTitle><navMap>{nav_points}</navMap></ncx>')
        zf.writestr("OEBPS/style.css", css)
        font_path = _FONT_PATH
        if font_path.exists():
            zf.write(str(font_path), "OEBPS/fonts/Sahel.ttf")
        zf.writestr("OEBPS/title.xhtml", f'<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml" dir="rtl"><head><title>{title_safe}</title><link rel="stylesheet" href="style.css"/></head><body><h1>{title_safe}</h1></body></html>'.encode("utf-8"))
        zf.writestr("OEBPS/nav.xhtml", f'<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" dir="rtl"><head><title>فهرست</title></head><body><nav epub:type="toc"><h1>فهرست</h1><ol>{nav_li}</ol></nav></body></html>'.encode("utf-8"))
        for i, section in enumerate(sections):
            lines = section.split("\n", 1)
            ch_title = xml_escape(lines[0].strip().replace("---", "").strip() or f"بخش {i+1}")
            content = lines[1].strip() if len(lines) > 1 else ""
            paras = "".join(f"<p>{xml_escape(p.strip())}</p>\n" for p in content.split("\n") if p.strip())
            zf.writestr(f"OEBPS/{chapter_files[i]}", f'<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml" dir="rtl"><head><title>{ch_title}</title><link rel="stylesheet" href="style.css"/></head><body><h2>{ch_title}</h2>{paras}</body></html>'.encode("utf-8"))

    console.print(f"  💾 ذخیره شد: [bold green]{path}[/] ({path.stat().st_size:,} بایت)")
    return str(path)
