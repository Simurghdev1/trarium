"""تقسیم‌کننده متن به بخش‌های مناسب برای API."""
import re


class TextChunker:
    """متن رو به بخش‌های کوچک‌تر تقسیم می‌کنه تا در محدودیت API جا بشه."""

    def __init__(self, max_chars: int = 15000, overlap: int = 200):
        """
        max_chars: حداکثر کاراکتر هر بخش
        overlap: همپوشانی بین بخش‌ها (برای حفظ زمینه)
        """
        if max_chars <= 0:
            raise ValueError("max_chars باید بزرگ‌تر از صفر باشد")
        if overlap < 0 or overlap >= max_chars:
            raise ValueError("overlap باید بین صفر و max_chars-1 باشد")
        self.max_chars = max_chars
        self.overlap = overlap

    def chunk_by_chapters(self, chapters: list[dict]) -> list[dict]:
        """متن رو بر اساس فصل‌ها تقسیم می‌کنه."""
        chunks = []
        current_chunk = ""
        current_title = ""

        for chapter in chapters:
            chapter_text = chapter["content"]
            chapter_title = chapter["title"]

            # هر ورودی chapters یک فصل مستقل است؛ حتی اگر دو فصل عنوان یکسانی داشته باشند.
            if current_chunk:
                chunks.append({
                    "title": current_title,
                    "content": current_chunk.strip(),
                })
                current_chunk = ""

            current_title = chapter_title

            # اگه فصل اندازه‌اش از حداکثر بیشتر نیست
            if len(current_chunk) + len(chapter_text) <= self.max_chars:
                current_chunk += "\n\n" + chapter_text if current_chunk else chapter_text
            else:
                # فصل رو هم به بخش‌های کوچک‌تر تقسیم کن
                if current_chunk.strip():
                    chunks.append({
                        "title": current_title,
                        "content": current_chunk.strip(),
                    })
                    current_chunk = ""

                # تقسیم فصل طولانی
                sub_chunks = self.chunk_text(chapter_text)
                for i, sc in enumerate(sub_chunks):
                    chunks.append({
                        "title": f"{chapter_title} (بخش {i + 1})",
                        "content": sc,
                    })

        # آخرین chunk
        if current_chunk.strip():
            chunks.append({
                "title": current_title,
                "content": current_chunk.strip(),
            })

        return chunks

    def chunk_text(self, text: str) -> list[str]:
        """متن ساده رو به بخش‌های کوچک‌تر تقسیم می‌کنه — هوشمند (جمله‌محور)."""
        if len(text) <= self.max_chars:
            return [text]

        chunks = []
        start = 0

        while start < len(text):
            end = start + self.max_chars

            if end < len(text):
                # اول تلاش کن آخر جمله بشکنه (. ! ?)
                break_point = -1
                for pattern in [r"\.\s", r"!\s", r"\?\s", r"\.\n", r"!\n", r"\?\n"]:
                    bp = list(re.finditer(pattern, text[start + self.max_chars // 3:end]))
                    if bp:
                        break_point = start + self.max_chars // 3 + bp[-1].end()

                # اگه جمله پیدا نشد، خط جدید
                if break_point == -1:
                    break_point = text.rfind("\n", start + self.max_chars // 2, end)

                # اگه خط هم پیدا نشد، فاصله
                if break_point == -1:
                    break_point = text.rfind(" ", start + self.max_chars // 2, end)

                if break_point != -1:
                    end = break_point + 1

            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)

            # overlap فقط برای context است؛ از برگشتن به نقطه قبلی جلوگیری کن.
            next_start = end - self.overlap
            if next_start <= start:
                next_start = end
            start = next_start

        return chunks
